import lyricsgenius
genius = lyricsgenius.Genius("pheG1JD95JN3D4jDTKU0P3zDeNJIW7xJjOC9s6ahbrtX2iTngvNEQOJrskzWfBas")
artist = genius.search_artist("Drake", max_songs=3, sort="title")
print(artist.songs)

song = genius.search_song("To You", artist.name)
print(song.lyrics)
